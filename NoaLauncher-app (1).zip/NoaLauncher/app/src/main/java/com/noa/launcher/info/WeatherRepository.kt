package com.noa.launcher.info

import com.noa.launcher.settings.City
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

data class Weather(
    val temp: Int, val feels: Int, val humidity: Int, val wind: Int,
    val code: Int, val isDay: Boolean, val max: Int, val min: Int, val rain: Int
)

/** Open-Meteo: gratuito, sem chave de API. */
object WeatherRepository {

    suspend fun fetch(c: City): Weather? = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lon}" +
                "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,is_day" +
                "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&timezone=auto&forecast_days=1"
            val j = JSONObject(httpGet(url))
            val cur = j.getJSONObject("current")
            val d = j.getJSONObject("daily")
            Weather(
                temp = cur.getDouble("temperature_2m").roundToInt(),
                feels = cur.getDouble("apparent_temperature").roundToInt(),
                humidity = cur.getInt("relative_humidity_2m"),
                wind = cur.getDouble("wind_speed_10m").roundToInt(),
                code = cur.getInt("weather_code"),
                isDay = cur.optInt("is_day", 1) == 1,
                max = d.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
                min = d.getJSONArray("temperature_2m_min").getDouble(0).roundToInt(),
                rain = d.getJSONArray("precipitation_probability_max").optInt(0, 0)
            )
        } catch (e: Exception) {
            null
        }
    }

    suspend fun searchCity(query: String): City? = withContext(Dispatchers.IO) {
        try {
            val q = URLEncoder.encode(query.trim(), "UTF-8")
            val j = JSONObject(httpGet("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=pt&format=json"))
            val r = j.optJSONArray("results") ?: return@withContext null
            val first = r.getJSONObject(0)
            City(first.getString("name"), first.getDouble("latitude"), first.getDouble("longitude"))
        } catch (e: Exception) {
            null
        }
    }

    fun describe(code: Int, isDay: Boolean): Pair<String, String> = when (code) {
        0 -> (if (isDay) "☀" else "☾") to "CÉU LIMPO"
        1, 2 -> "⛅" to "POUCAS NUVENS"
        3 -> "☁" to "NUBLADO"
        45, 48 -> "≋" to "NEBLINA"
        in 51..57 -> "☂" to "GAROA"
        in 61..67 -> "☂" to "CHUVA"
        in 71..77, 85, 86 -> "❄" to "NEVE"
        in 80..82 -> "☂" to "PANCADAS"
        in 95..99 -> "⚡" to "TEMPESTADE"
        else -> "•" to "—"
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
