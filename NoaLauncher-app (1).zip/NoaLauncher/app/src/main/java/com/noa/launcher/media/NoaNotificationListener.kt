package com.noa.launcher.media

import android.service.notification.NotificationListenerService

/** Serviço vazio: só existe para o Android liberar a leitura das sessões de mídia (Spotify etc.). */
class NoaNotificationListener : NotificationListenerService()
