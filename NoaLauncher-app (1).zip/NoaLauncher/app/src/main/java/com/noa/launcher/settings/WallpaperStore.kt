package com.noa.launcher.settings

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import kotlin.math.max

/** Guarda a imagem escolhida na galeria (já reduzida) e avisa o WallpaperService. */
object WallpaperStore {
    fun file(ctx: Context) = File(ctx.filesDir, "wallpaper.jpg")

    fun saveFromUri(ctx: Context, uri: Uri): Boolean = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        val longest = max(bounds.outWidth, bounds.outHeight)
        while (longest / sample > 2400) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }!!
        file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        bmp.recycle()
        NoaPrefs.get(ctx).edit()
            .putString(NoaPrefs.KEY_WP_MODE, "image")
            .putLong(NoaPrefs.KEY_WP_VERSION, System.currentTimeMillis())
            .apply()
        true
    } catch (e: Exception) {
        false
    }

    fun restoreCyber(ctx: Context) {
        NoaPrefs.get(ctx).edit()
            .putString(NoaPrefs.KEY_WP_MODE, "cyber")
            .putLong(NoaPrefs.KEY_WP_VERSION, System.currentTimeMillis())
            .apply()
    }
}
