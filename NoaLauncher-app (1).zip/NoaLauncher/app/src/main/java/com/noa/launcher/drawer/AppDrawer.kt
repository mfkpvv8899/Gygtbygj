package com.noa.launcher.drawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noa.launcher.settings.UiPrefs
import com.noa.launcher.ui.Cy
import com.noa.launcher.ui.MonoText
import com.noa.launcher.ui.SmallCut

/**
 * O blur do fundo é aplicado na JANELA (HomeActivity); aqui só pintamos um véu escuro por cima.
 * Toque longo em um app = fixar/desafixar nos atalhos da tela inicial.
 */
@Composable
fun AppDrawer(
    apps: List<AppInfo>,
    query: String,
    ui: UiPrefs,
    accent: Color,
    pinnedKeys: List<String>,
    onQuery: (String) -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onTogglePin: (AppInfo) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .fillMaxSize()
            .background(Color(0xFF020409).copy(alpha = ui.glass(0.62f)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .weight(1f)
                    .clip(SmallCut)
                    .border(1.dp, accent.copy(alpha = ui.line(0.7f)), SmallCut)
                    .background(Cy.Panel.copy(alpha = ui.glass(0.6f)))
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                if (query.isEmpty()) MonoText("> BUSCAR APP_", color = Cy.Dim, size = 14)
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = Cy.Text, fontSize = 14.sp, fontFamily = FontFamily.Monospace),
                    cursorBrush = SolidColor(accent),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier
                    .size(46.dp)
                    .clip(SmallCut)
                    .border(1.dp, accent.copy(alpha = ui.line(0.8f)), SmallCut)
                    .clickable(onClick = onClose),
                contentAlignment = Alignment.Center
            ) { MonoText("✕", color = accent, size = 18, bold = true) }
        }
        Spacer(Modifier.height(6.dp))
        MonoText("segure um app para fixar nos atalhos", color = Cy.Dim, size = 10)
        Spacer(Modifier.height(10.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(apps, key = { it.component.flattenToString() }) { app ->
                val pinned = pinnedKeys.contains(app.component.flattenToString())
                Column(
                    Modifier.pointerInput(app.component) {
                        detectTapGestures(
                            onTap = { onLaunch(app) },
                            onLongPress = { onTogglePin(app) }
                        )
                    },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(app.icon, app.label, Modifier.size(50.dp))
                    Spacer(Modifier.height(5.dp))
                    MonoText(
                        (if (pinned) "◆ " else "") + app.label,
                        color = if (pinned) accent else Cy.Text.copy(alpha = 0.85f),
                        size = 10, align = TextAlign.Center
                    )
                }
            }
        }
    }
}
