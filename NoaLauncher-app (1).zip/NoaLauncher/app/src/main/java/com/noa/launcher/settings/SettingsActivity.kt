package com.noa.launcher.settings

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.noa.launcher.drawer.AppInfo
import com.noa.launcher.drawer.AppRepository
import com.noa.launcher.info.WeatherRepository
import com.noa.launcher.ui.CyberButton
import com.noa.launcher.ui.CyberPanel
import com.noa.launcher.ui.Cy
import com.noa.launcher.ui.MonoText
import com.noa.launcher.ui.SmallCut
import com.noa.launcher.wallpaper.MotionWallpaperService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent { SettingsRoot(onClose = { finish() }) }
    }
}

@Composable
private fun SettingsRoot(onClose: () -> Unit) {
    var page by remember { mutableStateOf("main") }
    BackHandler(enabled = page != "main") { page = "main" }

    Box(Modifier.fillMaxSize().background(Cy.Bg)) {
        if (page == "main") MainPage(onClose = onClose, onPickApps = { page = "apps" })
        else AppsPage(onBack = { page = "main" })
    }
}

// =============================================================== Página principal
@Composable
private fun MainPage(onClose: () -> Unit, onPickApps: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { NoaPrefs.get(ctx) }
    val ui0 = remember { NoaPrefs.readUi(ctx) }

    var transparent by remember { mutableStateOf(ui0.transparentMode) }
    var level by remember { mutableFloatStateOf(ui0.transparency) }
    var blur by remember { mutableFloatStateOf(ui0.blur) }
    var accentIdx by remember { mutableIntStateOf(ui0.accent) }
    var sens by remember { mutableFloatStateOf(NoaPrefs.sensitivity(ctx)) }
    var particles by remember { mutableStateOf(NoaPrefs.particles(ctx)) }
    var cityName by remember { mutableStateOf(NoaPrefs.readCity(ctx).name) }
    var cityQuery by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var pinnedCount by remember { mutableIntStateOf(NoaPrefs.pinned(ctx).size) }
    var mediaOk by remember { mutableStateOf(false) }

    val accent = Color(NoaPrefs.ACCENTS[accentIdx.coerceIn(0, NoaPrefs.ACCENTS.size - 1)])
    val ui = remember(transparent, level, blur, accentIdx) { UiPrefs(transparent, level, blur, accentIdx) }

    LaunchedEffect(Unit) {
        mediaOk = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
        pinnedCount = NoaPrefs.pinned(ctx).size
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { WallpaperStore.saveFromUri(ctx, uri) }
                status = if (ok) "Wallpaper atualizado. Ative o Nôa Motion abaixo se ainda não estiver ativo."
                else "Não consegui carregar essa imagem."
            }
        }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Cabeçalho + botão FECHAR
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                MonoText("// CONFIG", color = accent, size = 22, bold = true, spacing = 2)
                MonoText("NÔA//OS", color = Cy.Dim, size = 11, spacing = 3)
            }
            Box(
                Modifier.size(46.dp).clip(SmallCut).border(1.dp, accent, SmallCut).clickable(onClick = onClose),
                contentAlignment = Alignment.Center
            ) { MonoText("✕", color = accent, size = 20, bold = true) }
        }

        if (status.isNotEmpty()) {
            CyberPanel(Modifier.fillMaxWidth(), ui, accent, padding = 10.dp) {
                MonoText(status, color = Cy.Text, size = 11, maxLines = 4)
            }
        }

        // ---------------- APARÊNCIA
        CyberPanel(Modifier.fillMaxWidth(), ui, accent, title = "APARÊNCIA") {
            ToggleRow("TUDO TRANSPARENTE", "painéis, busca e drawer translúcidos", transparent, accent) {
                transparent = it; prefs.edit().putBoolean(NoaPrefs.KEY_TRANSPARENT_MODE, it).apply()
            }
            if (transparent) {
                MonoText("TRANSPARÊNCIA ${(level * 100).roundToInt()}%", color = Cy.Text, size = 11)
                NeonSlider(level, accent) { level = it; prefs.edit().putFloat(NoaPrefs.KEY_TRANSPARENCY, it).apply() }
            }
            MonoText("BLUR DO DRAWER ${(blur * 100).roundToInt()}%", color = Cy.Text, size = 11)
            NeonSlider(blur, accent) { blur = it; prefs.edit().putFloat(NoaPrefs.KEY_BLUR, it).apply() }
            MonoText("COR DE DESTAQUE", color = Cy.Text, size = 11)
            Spacer(Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                NoaPrefs.ACCENTS.indices.toList().chunked(3).forEach { rowIdx ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        rowIdx.forEach { i ->
                            val c = Color(NoaPrefs.ACCENTS[i])
                            Box(
                                Modifier.weight(1f).height(40.dp).clip(SmallCut)
                                    .background(c.copy(alpha = 0.18f))
                                    .border(if (i == accentIdx) 2.dp else 1.dp, c, SmallCut)
                                    .clickable { accentIdx = i; prefs.edit().putInt(NoaPrefs.KEY_ACCENT, i).apply() },
                                contentAlignment = Alignment.Center
                            ) { MonoText(NoaPrefs.ACCENT_NAMES[i], color = c, size = 10, bold = true) }
                        }
                    }
                }
            }
        }

        // ---------------- WALLPAPER
        CyberPanel(Modifier.fillMaxWidth(), ui, accent, title = "WALLPAPER") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CyberButton("ESCOLHER IMAGEM", accent, ui, Modifier.weight(1f), filled = true) { picker.launch("image/*") }
                CyberButton("CIBER PADRÃO", accent, ui, Modifier.weight(1f)) {
                    WallpaperStore.restoreCyber(ctx); status = "Wallpaper cibernético restaurado."
                }
            }
            Spacer(Modifier.height(10.dp))
            MonoText("SENSIBILIDADE ${(sens * 100).roundToInt()}%", color = Cy.Text, size = 11)
            NeonSlider(sens, accent) { sens = it; prefs.edit().putFloat(NoaPrefs.KEY_SENSITIVITY, it).apply() }
            ToggleRow("PARTÍCULAS", "mais leve se desligado", particles, accent) {
                particles = it; prefs.edit().putBoolean(NoaPrefs.KEY_PARTICLES, it).apply()
            }
            Spacer(Modifier.height(6.dp))
            CyberButton("ATIVAR WALLPAPER NÔA MOTION", accent, ui, Modifier.fillMaxWidth()) { applyWallpaper(ctx) }
        }

        // ---------------- CLIMA
        CyberPanel(Modifier.fillMaxWidth(), ui, accent, title = "CLIMA") {
            MonoText("CIDADE ATUAL: ${cityName.uppercase()}", color = Cy.Text, size = 11)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.weight(1f).clip(SmallCut).border(1.dp, accent.copy(alpha = 0.6f), SmallCut)
                        .padding(horizontal = 12.dp, vertical = 12.dp)
                ) {
                    if (cityQuery.isEmpty()) MonoText("digite a cidade...", color = Cy.Dim, size = 13)
                    BasicTextField(
                        value = cityQuery, onValueChange = { cityQuery = it }, singleLine = true,
                        textStyle = TextStyle(color = Cy.Text, fontSize = 13.sp, fontFamily = FontFamily.Monospace),
                        cursorBrush = SolidColor(accent), modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.width(8.dp))
                CyberButton("BUSCAR", accent, ui, filled = true) {
                    if (cityQuery.isNotBlank()) scope.launch {
                        val c = WeatherRepository.searchCity(cityQuery)
                        if (c != null) {
                            NoaPrefs.setCity(ctx, c); cityName = c.name; cityQuery = ""
                            status = "Cidade definida: ${c.name}"
                        } else status = "Cidade não encontrada (precisa de internet)."
                    }
                }
            }
        }

        // ---------------- ATALHOS
        CyberPanel(Modifier.fillMaxWidth(), ui, accent, title = "ATALHOS") {
            MonoText("$pinnedCount/${NoaPrefs.MAX_PINNED} apps na tela inicial", color = Cy.Text, size = 11)
            Spacer(Modifier.height(8.dp))
            CyberButton("ESCOLHER APPS", accent, ui, Modifier.fillMaxWidth(), filled = true, onClick = onPickApps)
        }

        // ---------------- MÚSICA
        CyberPanel(Modifier.fillMaxWidth(), ui, accent, title = "MÚSICA") {
            MonoText(
                if (mediaOk) "leitura da faixa: ATIVA" else "leitura da faixa: DESATIVADA (os botões já funcionam)",
                color = Cy.Text, size = 11, maxLines = 2
            )
            Spacer(Modifier.height(8.dp))
            CyberButton(
                if (mediaOk) "GERENCIAR ACESSO" else "ATIVAR ACESSO A NOTIFICAÇÕES", accent, ui, Modifier.fillMaxWidth()
            ) {
                try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (e: Exception) { }
            }
        }

        CyberButton("FECHAR", accent, ui, Modifier.fillMaxWidth(), filled = true, onClick = onClose)
        Spacer(Modifier.height(8.dp))
    }
}

// =============================================================== Escolher apps
@Composable
private fun AppsPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val accent = Color(NoaPrefs.ACCENTS[NoaPrefs.readUi(ctx).accent.coerceIn(0, NoaPrefs.ACCENTS.size - 1)])
    val ui = remember { UiPrefs() }
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var keys by remember { mutableStateOf(NoaPrefs.pinned(ctx)) }
    var q by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { apps = AppRepository(ctx).loadApps() }

    val shown = if (q.isBlank()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                MonoText("// ATALHOS", color = accent, size = 20, bold = true, spacing = 2)
                MonoText("${keys.size}/${NoaPrefs.MAX_PINNED} selecionados", color = Cy.Dim, size = 11)
            }
            CyberButton("OK", accent, ui, filled = true, onClick = onBack)
        }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier.fillMaxWidth().clip(SmallCut).border(1.dp, accent.copy(alpha = 0.6f), SmallCut)
                .padding(horizontal = 12.dp, vertical = 12.dp)
        ) {
            if (q.isEmpty()) MonoText("> buscar", color = Cy.Dim, size = 13)
            BasicTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                textStyle = TextStyle(color = Cy.Text, fontSize = 13.sp, fontFamily = FontFamily.Monospace),
                cursorBrush = SolidColor(accent), modifier = Modifier.fillMaxWidth()
            )
        }
        if (msg.isNotEmpty()) { Spacer(Modifier.height(6.dp)); MonoText(msg, color = accent, size = 11) }
        Spacer(Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(shown, key = { it.component.flattenToString() }) { app ->
                val k = app.component.flattenToString()
                val on = keys.contains(k)
                Row(
                    Modifier.fillMaxWidth().clip(SmallCut)
                        .border(1.dp, if (on) accent else Cy.Dim.copy(alpha = 0.25f), SmallCut)
                        .clickable {
                            val list = keys.toMutableList()
                            if (list.remove(k)) { msg = "" }
                            else if (list.size >= NoaPrefs.MAX_PINNED) { msg = "Limite de ${NoaPrefs.MAX_PINNED} atalhos atingido." }
                            else list.add(k)
                            keys = list
                            NoaPrefs.setPinned(ctx, list)
                        }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(app.icon, app.label, Modifier.size(34.dp))
                    Spacer(Modifier.width(12.dp))
                    MonoText(app.label, color = Cy.Text, size = 13, modifier = Modifier.weight(1f))
                    MonoText(if (on) "[■]" else "[ ]", color = if (on) accent else Cy.Dim, size = 14, bold = true)
                }
            }
        }
    }
}

// =============================================================== Componentes
@Composable
private fun NeonSlider(value: Float, accent: Color, onChange: (Float) -> Unit) {
    Slider(
        value = value, onValueChange = onChange,
        colors = SliderDefaults.colors(
            thumbColor = accent, activeTrackColor = accent, inactiveTrackColor = accent.copy(alpha = 0.25f)
        )
    )
}

@Composable
private fun ToggleRow(title: String, sub: String, checked: Boolean, accent: Color, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            MonoText(title, color = Cy.Text, size = 12, bold = true)
            MonoText(sub, color = Cy.Dim, size = 10, maxLines = 2)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Cy.Bg, checkedTrackColor = accent,
                uncheckedThumbColor = Cy.Dim, uncheckedTrackColor = Cy.Panel,
                uncheckedBorderColor = Cy.Dim
            )
        )
    }
}

private fun applyWallpaper(ctx: Context) {
    val cn = ComponentName(ctx, MotionWallpaperService::class.java)
    try {
        ctx.startActivity(
            Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, cn)
        )
    } catch (e: Exception) {
        try { ctx.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) } catch (e2: Exception) { }
    }
}
