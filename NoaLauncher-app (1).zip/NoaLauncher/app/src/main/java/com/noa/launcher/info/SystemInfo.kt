package com.noa.launcher.info

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import androidx.core.content.ContextCompat
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

data class BatteryInfo(val level: Int = -1, val charging: Boolean = false)
data class SysInfo(val storageFreeGb: Int = 0, val storageTotalGb: Int = 0, val net: String = "—")

object SystemInfo {

    fun batteryFlow(ctx: Context): Flow<BatteryInfo> = callbackFlow<BatteryInfo> {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { if (i != null) trySend(parse(i)) }
        }
        val sticky = ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        if (sticky != null) trySend(parse(sticky))
        awaitClose { ctx.unregisterReceiver(receiver) }
    }

    private fun parse(i: Intent): BatteryInfo {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return BatteryInfo(pct, charging)
    }

    fun read(ctx: Context): SysInfo {
        val st = StatFs(Environment.getDataDirectory().path)
        val free = (st.availableBytes / 1_000_000_000L).toInt()
        val total = (st.totalBytes / 1_000_000_000L).toInt()
        return SysInfo(free, total, network(ctx))
    }

    private fun network(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return "OFFLINE"
        val c = cm.getNetworkCapabilities(n) ?: return "OFFLINE"
        return when {
            c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WI-FI"
            c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "MÓVEL"
            c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETH"
            else -> "ONLINE"
        }
    }
}
